import Login from "@/components/loginComponents/Login";

export default function LoginPage() {
  return <Login />;
}
