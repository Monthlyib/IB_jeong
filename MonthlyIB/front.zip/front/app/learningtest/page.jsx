import LearningStyleTest from "@/components/learningStyleTest/LearningStyleComponenets";

export default function LearningTest() {
  return <LearningStyleTest />;
}
