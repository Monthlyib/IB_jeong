import QuestionComponents from "@/components/questionComponents/QuestionComponents";

export default async function Question() {
  return <QuestionComponents />;
}
