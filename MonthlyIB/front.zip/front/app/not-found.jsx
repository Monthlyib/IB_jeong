export default function NotFound() {
  return <h1 color="red">Not found</h1>;
}
