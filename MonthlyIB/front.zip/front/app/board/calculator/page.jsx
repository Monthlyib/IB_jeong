import Calculator from "../../../components/boardComponents/calculator/Calculator";

const Calc = () => {
  return (
    <>
      <Calculator />
    </>
  );
};

export default Calc;
