import SocialLogin from "@/components/loginComponents/SocialLogin";

const Google = () => {
  const social = 1;
  return (
    <>
      <SocialLogin social={social} />
    </>
  );
};

export default Google;
