const CoursePlayerLayout = ({ children }) => {
  return <>{children}</>;
};

export default CoursePlayerLayout;
