import SocialLogin from "@/components/loginComponents/SocialLogin";

const Naver = () => {
  const social = 3;
  return (
    <>
      <SocialLogin social={social} />
    </>
  );
};

export default Naver;
