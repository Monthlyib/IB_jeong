import SocialLogin from "@/components/loginComponents/SocialLogin";

const Kakao = () => {
  const social = 2;
  return (
    <>
      <SocialLogin social={social} />
    </>
  );
};

export default Kakao;
