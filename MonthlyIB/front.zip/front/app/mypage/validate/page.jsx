import Validate from "@/components/mypageComponents/Validate";

const ValidateHome = () => {
  return <Validate />;
};

export default ValidateHome;
