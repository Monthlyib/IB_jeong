import TutoringComponents from "@/components/tutoringComponents/TutoringComponents";

export default function TutoringPage() {
  return <TutoringComponents />;
}
